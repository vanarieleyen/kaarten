<?php

/*
	the iddle loop:
	find the player, set its name and pass
	set the start status
	get the hands of each player
*/
extract($_GET);

$found = false;
$tables = glob("table.*");

foreach ($tables AS $table) {
	$status = json_decode(file_get_contents($table));
	foreach ($status->players AS $key => $val) {
		if ($val->ID == $player) {		// table found
			$val->name = $name;
			$status->time = time();	// update the activity time
			$finished = $status->finished;
			$found = true;
			break;
		}
	}
	if ($found)
		break;
}

// check if the game has ended
foreach ($status->players AS $key => $val) {
	if (count($val->hand) == 0) {		// end game
		$status->started = 0;			// the started status of the table
		$status->bid = 0;					// the current bid
		$status->pass = 0;				// amount of passes
		$status->turn = '';
		$status->finished = 1;
		break;
	}
}

if ($status->finished == 0) {
	if ($status->started == 0)
		$status->started = $start;
}

// make sure another process doesn't overwrite the status when finished
if ($finished == 0) 
	file_put_contents($table, json_encode($status));	// save the new status
	
echo json_encode($status);





?>