<?php

/*
	input: player (only used to find the active table)
			skip (1/0) 
	calculates the scores of the players
*/

extract($_GET);

$tables = glob("table.*");
$result = array();

foreach ($tables AS $table) {
	$status = json_decode(file_get_contents($table));

	foreach ($status->players AS $k => $v) {
		if ($v->ID == $player) {		// table found
			foreach ($status->players AS $key => $val) {
				$cardsLeft = count($val->hand);
				$multiply = 0;
				switch (true) {
					case ($cardsLeft == 13):						$multiply++;
					case in_array($cardsLeft, range(12, 10)):	$multiply++;
					case in_array($cardsLeft, range(9, 7)):	$multiply++;
					case in_array($cardsLeft, range(6, 1)):	$multiply++;
					default: break;
				}
				$result[] = array($val->name, $multiply*$cardsLeft);
			}
			break;
		}
	}
}

echo json_encode($result);
?>