<?php

/*
	input: 
		player: current player id
		deal: the cards that are put on the table 
		turn: the next player
	find the player
	checks if the deal is valid
	updates the status
*/

extract($_GET);

				
$ok = false;
$tables = glob("table.*");

function udiffCompare($a, $b) {
	$valA = $a[0]*100+$a[1];
	$valB = $b[0]*100+$b[1];
	return $valA - $valB;
}

// remove quotes from deal array values
function toInt($a) {
	$a[0] = intval($a[0]);
	$a[1] = intval($a[1]);
	return $a;
}
$deal = array_map('toInt', $deal);

$found = false;
foreach ($tables AS $table) {
	$status = json_decode(file_get_contents($table));
	foreach ($status->players AS $key => $val) {
		$found = ($val->ID == $player);
		if ($found) {		// table found
			$status->time = time();		// update the activity time
			$status->pass = 0;
			$status->bid = $deal;
			$status->turn = $turn;
			
			// subtract the deal from the cards in the hand
			$val->hand = array_values(array_udiff($val->hand, $deal, "udiffCompare"));
			file_put_contents($table, json_encode($status));	// save the new status
			break;
		}
	}
	if ($found)	break;
}

$result = array();
$result['ok'] = $found;
echo json_encode($result);

// check to see if the deal is according to the bid and has a higher value
function valid($bid, $deal) {
	if (count($bid) != count($deal))		// check the amount of cards
		return false;

	if (typeof($bid) < typeof($deal))		// check the type of street
		return true;
	
	$val_bid = evaluate($bid);
	$val_deal = evaluate($deal);
	return $val_bid < $val_deal;
}

// returns the value of the deal
function evaluate($cards) {
	$len = count($cards);
	if ($len < 5)
		return $cards[$len-1][0]+4*$cards[$len-1][1];	// only use the highest card

	$street = typeof($cards);		// 1..8
	$pnt = 0;
	if ($street==6 || $street==7) {
		$firstCard = $cards[0][1];
		$a = 0;
		$b = 0;
		$sumA = 0;
		$sumB = 0;
		foreach ($cards AS $key => $val) {
			if ($val[1] != $firstCard) {
				$a++;
				$sumA += $val[1];
			} else {
				$b++;
				$sumB += $val[1];
			}
		}
		$pnt = ($a > $b) ? $sumA : $sumB;
	} else {
		return $cards[$len-1][0]+4*$cards[$len-1][1];	// only use the highest card
	}
	// $pnt can not be higher than 6565, so $street must be multiplied by 6565 or higher
	return 10000*$street+$pnt;
}

// check the deal 
// return: dealtype or 0 on error
function typeof($deal) {
	$len = count($deal);
	switch ($len) {
		case 1: 	return 1;
		case 2: 	$bits = $deal[0][1] & $deal[1][1];
					return ($bits == $deal[0][1]) ? 2 : 0;
		case 3:	$bits = $deal[0][1] & $deal[1][1] & $deal[2][1];
					return ($bits == $deal[0][1]) ? 3 : 0;
		case 5:	$straight = isStraight($deal);
					$flush = isFlush($deal);
					$fullhouse = isFullhouse($deal);
					$fourkind = is4kind($deal);
					if ($straight && $flush) {
						return 8;
					} elseif ($fourkind) {
						return 7;
					} elseif ($fullhouse) {
						return 6;
					} elseif ($flush) {
						return 5;
					} elseif ($straight) {
						return 4;
					} else
						return 0;
					break;
		default:	return 0;
	}
}	

// is 5 in a row (various suits)
function isStraight($deal) {
	$next = $deal[0][1];
	foreach ($deal AS $card) {
		if ($card[1] != $next)
			return ($card[1]==13);
		$next++; 
	}
	return true;
}

// is 5 with the same suits
function isFlush($deal) {
	$suit = $deal[0][0];
	foreach ($deal AS $card) {
		if ($card[0] != $suit)
			return false;
	}
	return true;
}

// is 3 + 2 the same suits
function isFullhouse($deal) {
	if (($deal[0][1]-$deal[1][1] | $deal[3][1]-$deal[4][1]) == 0) {
		return ($deal[2][1]==$deal[0][1] || $deal[2][1]==$deal[4][1]);
	}
	return false;
}

// is 4 of a kind (1 + 4 same suits)
function is4kind($deal) {
	return ($deal[1][1] == $deal[2][1] && $deal[1][1] == $deal[3][1]);	// middle 3 cards must be the same
}



?>