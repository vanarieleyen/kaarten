<?php

/*
	adds a new player to a table
	adds a new table when necessary
	sets started to 0 (waiting for start)
	remove inactive tables
	get the hands of each player
*/

extract($_GET);

$inactive = 60*5; // set 5 minutes for table removal

$tables = glob("table.*");

$ok = ($tables == false || count($tables) == 0 ) ? false : true;

if ($ok) {
	$last = 0;
	foreach ($tables AS $table) {		// remove inactive tables and get the latest table
		$status = json_decode(file_get_contents($table));
		if ($status->time > $last) {		// select most recent table
			$current_table = $table;
			$last = $status->time;
		}
		if ($status->time < time()-$inactive) {
			unlink($table);
			$current_table = "table.1";
		}
	}
} else {
	$current_table = "table.1";
	$status = null;
}

if (file_exists($current_table)) {
	$status = json_decode(file_get_contents($current_table));
	if ($status->started == "1") { 	
		$tables = glob("table.*");	// create a new table name
		$nr = 0;
		foreach($tables AS $table) {
			$tmp = explode(".", $table);
			if ($tmp[1] > $nr) 
				$nr = $tmp[1];
		}
		$current_table = sprintf("table.%d", $nr+1);	// new table
		$status = null;
	}
} else {
	$current_table = "table.1";
	$status = null;
}

// make sure the player is only once on the table
if ($status != null) {
	foreach ($status->players AS $key => $val) {
		if ($val->ID == $player) {		// player is already on the table
			echo json_encode($status);
			return;
		}
	}
}

function fyshuffle(&$items, $seedstring) {
	if (!$seedstring) {
		$seedval = time();
	} else {
		if (is_numeric($seedstring)) {
			$seedval = $seedstring;
		} else {
			for ($i=0;$i<=strlen($seedstring);$i++) {
				$seedval += ord($seedstring[$i]);
			}
		}
 
		srand($seedval);
		for ($i = count($items) - 1; $i > 0; $i--) {
			$j = @rand(0, $i);
			$tmp = $items[$i];
			$items[$i] = $items[$j];
			$items[$j] = $tmp;
		}
 	}
}
    
// sort low to high (keeps suits together)
function sortByValue($a, $b) {
	if ($a[0] > $b[0]) {
		return true;
	} elseif($a[0] == $b[0]) {
		return $a[1] - $b[1];
	} else {
		return false;
	}	
}

// sort low to high (keeps ranks together)
function sortByOrder($a, $b) {
	if ($a[1] > $b[1]) {
		return true;
	} elseif($a[1] == $b[1]) {
		return $a[0] - $b[0];
	} else {
		return false;
	}	
}

// returns which player has the lowest card (playerA, playerB etc..)
function FirstPlay($players) {
	$player = "";
	foreach ($players AS $key => $val) {
		foreach ($val['hand'] AS $card) {
			if ($card[0] == 1 && $card[1] == 1) {
				$player = $key;
			}
		}
		if ($player != "")
			break;
	}
	return $player;
}

function newTable() {
	global $cards, $player, $start;
	
	$status = array();
	$players = array();
	$status['time'] = time();			// the last activity time
	$status['started'] = $start;		// the started status of the table
	$status['bid'] = 0;					// the current bid
	$status['pass'] = 0;					// amount of passes
	$status['finished'] = 0;
	$handA = array_slice($cards, 0, 13);
	usort($handA, "sortByOrder");
	$players['playerA'] = array("ID"=>$player, name=>'', "hand"=>$handA);
	$handB = array_slice($cards, 13, 13);
	usort($handB, "sortByOrder");
	$players['playerB'] = array("ID"=>null, name=>'电脑(A)', "hand"=>$handB);
	$handC = array_slice($cards, 26, 13);
	usort($handC, "sortByOrder");
	$players['playerC'] = array("ID"=>null, name=>'电脑(B)', "hand"=>$handC);
	$handD = array_slice($cards, 39, 13);
	usort($handD, "sortByOrder");
	$players['playerD'] = array("ID"=>null, name=>'电脑(C)', "hand"=>$handD);
	$status['players'] = $players;
	
	$status['turn'] = FirstPlay($players);		// decide who has the lowest card and has to start
	
	return $status;
}

// when status does not exist create a new table
if ($status == null) {
	$cards = array();
	for ($kleur = 1; $kleur < 5; $kleur++)
		for ($kaart = 1; $kaart < 14; $kaart++)
			$cards[] = array($kleur, $kaart); 
			
	fyshuffle($cards, time());

	$status = newTable();
} else {	// add the player
	$seated = false;
	$i = 1;	// first occupy the N/S places
	foreach ($status->players AS $val) {
		if ($val->ID == null && $i % 2)	{
			$val->ID = $player;
			$seated = true;
		} 	
		$i++;
		if ($seated)	break;
	} 
	if (!$seated) {
		$i = 0;	// then occupy the E/W places
		foreach ($status->players AS $val) {
			if ($val->ID == null && $i % 2)	{
				$val->ID = $player;
				$seated = true;
			} 	
			$i++;
			if ($seated)	break;
		} 
	}
	
	// als er geen plek is dan een nieuwe tafel aanmaken
	if (!$seated) {
		$tables = glob("table.*");
		$nr = 0;
		foreach($tables AS $table) {
			$tmp = explode(".", $table);
			if ($tmp[1] > $nr) 
				$nr = $tmp[1];
		}
		$current_table = sprintf("table.%d", $nr+1);	// new table

		$cards = array();
		for ($kleur = 1; $kleur < 5; $kleur++)
			for ($kaart = 1; $kaart < 14; $kaart++)
				$cards[] = array($kleur, $kaart); 
				
		fyshuffle($cards, time());
	
		$status = newTable();
	}
}

// save the new status
file_put_contents($current_table, json_encode($status));

echo json_encode($status);

?>