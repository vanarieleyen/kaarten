<?php

// generate the classes for each card  
// to be included in the style sheet
// $size defines the scaling factor

list($height, $width) = getimagesize("images/RK.png");
$w = round($height/$size);
$h = round($width/$size);

$kind = array("R", "K", "H", "S");
$face = array("2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A");
for ($kleur = 1; $kleur < 5; $kleur++) {
	for ($kaart = 1; $kaart < 14; $kaart++) {
		$class = sprintf(".card%d%d", $kleur, $kaart); 
		$img = sprintf("images/%s%s.png", $kind[$kleur-1], $face[$kaart-1]);
		echo sprintf("
			%s {
			  display: none;
			  width: %spx;
			  height: %spx;
			  background-image: url('%s');
			  background-size: %spx %spx;
			  position: absolute;
			}", $class, $w, $h, $img, $w, $h);
	}
}
			
?>