<?php

/*
	input: player (only used to find the active table)
			turn: nextplayer 
	sets the next player
	updates the status
*/

extract($_GET);

$tables = glob("table.*");

foreach ($tables AS $table) {
	$status = json_decode(file_get_contents($table));
	foreach ($status->players AS $key => $val) {
		if ($val->ID == $player) {		// table found
			$status->time = time();		// update the activity time
			$status->pass++;
			$status->turn = $turn;
			file_put_contents($table, json_encode($status));
			break;
		}
	}
}

?>