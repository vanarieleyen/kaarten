<?php

/*
	input: player (only used to find the active table)
			
	restart the game status
*/

extract($_GET);

function fyshuffle(&$items, $seedstring) {
	if (!$seedstring) {
		$seedval = time();
	} else {
		if (is_numeric($seedstring)) {
			$seedval = $seedstring;
		} else {
			for ($i=0;$i<=strlen($seedstring);$i++) {
				$seedval += ord($seedstring[$i]);
			}
		}
 
		srand($seedval);
		for ($i = count($items) - 1; $i > 0; $i--) {
			$j = @rand(0, $i);
			$tmp = $items[$i];
			$items[$i] = $items[$j];
			$items[$j] = $tmp;
		}
 	}
}

// sort low to high (keeps ranks together)
function sortByOrder($a, $b) {
	if ($a[1] > $b[1]) {
		return true;
	} elseif($a[1] == $b[1]) {
		return $a[0] - $b[0];
	} else {
		return false;
	}	
}

// shuffle the cards
$cards = array();
for ($kleur = 1; $kleur < 5; $kleur++)
	for ($kaart = 1; $kaart < 14; $kaart++)
		$cards[] = array($kleur, $kaart); 
		
fyshuffle($cards, time());

// returns which player has a diamond-2 (playerA, playerB etc..)
function FirstPlay($players) {
	$player = "";
	foreach ($players AS $key => $val) {
		foreach ($val->hand AS $card) {
			if ($card[0] == 1 && $card[1] == 1) {
				$player = $key;
			}
		}
		if ($player != "")
			break;
	}
	return $player;
}

$tables = glob("table.*");

foreach ($tables AS $table) {
	$status = json_decode(file_get_contents($table));
	$current_table = $table;

	foreach ($status->players AS $key => $val) {
		if ($val->ID == $player) {		// table found
			$players = $status->players;
			$status->time = time();			// the last activity time
			$status->started = '0';			// the started status of the table
			$status->bid = 0;					// the current bid
			$status->pass = 0;					// amount of passes
			$status->finished = 0;
			$handA = array_slice($cards, 0, 13);
			usort($handA, "sortByOrder");
			$players->playerA->hand = $handA;
			$handB = array_slice($cards, 13, 13);
			usort($handB, "sortByOrder");
			$players->playerB->hand = $handB;
			$handC = array_slice($cards, 26, 13);
			usort($handC, "sortByOrder");
			$players->playerC->hand = $handC;
			$handD = array_slice($cards, 39, 13);
			usort($handD, "sortByOrder");
			$players->playerD->hand = $handD;
			
			$status->turn = FirstPlay($players);		// decide who has the lowest card and has to start
			
			// save the new status
			file_put_contents($current_table, json_encode($status));
			echo json_encode($status);
			break;
		}
	}
}



?>