<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
<title>Kaarten</title>

<link rel="stylesheet" type="text/css" href="master.css" />

<script type="text/javascript" src="js/jquery-3.1.0.min.js"></script>
<script type="text/javascript" src="js/jquery.countdown360.js"></script>
<script type="text/javascript" src="js/jquery.popup.js"></script>
<script type="text/javascript" src="js/functions.js"></script>


<script type="text/javascript" >

/*
	start game knop per player
	start: random id (tijd) naar server sturen om speler te kunnen identificeren
	als iedereen is gestart dan kaarten verdelen en game status opslaan op ieder client
	in status: voor iedere speler zijn kaarten, degene die aan de beurt is, score
	client laten pollen voor een nieuwe zet
	serverside de computer zetten berekenen
	
	php:
	shuffle() - shuffle cards en verdeel
	play() - een zet doen (kaarten op tafel leggen)
	score() - score bepalen en opslaan
	calc() - computerzet berekenen
*/

var countdown;					// the countdown timer
var skip = false;				// go to the next player
var turn = null;				// the current player on turn
var pause = false;
var pass = 0;					// pass indication
var passes = 0;				// the number of passes as reported from the server
var nextPlayer = '';	
var master = false;			// the player who starts the game
var player = uniqueID();
var deal = Array();			// the played cards
var bid = Array();			// the cards on the table
var started = 0;
var seconds = 2*1000;		// poll each 2 seconds
var finished = false;
var oldcardsleft = -1;
var cardsleft = 0;
var computer = false;		// true when it is the computers move


$(document).ready(function() {

	// preload all the cards
	for (var suit = 1; suit < 5; suit++) {
		for (var rank = 1; rank < 14; rank++) {
			$(".hand").append(sprintf("<div class='card card%s%s' angle='0' suit='%s' rank='%s'></div>", 
												suit, rank, suit, rank));
			$(".top").append(sprintf("<div class='blank_side card_h%s'></div>", rank));
			$('.left').append(sprintf("<div class='blank_side rotate card_v%s'></div>", rank));
			$('.right').append(sprintf("<div class='blank_side rotate card_v%s'></div>", rank));
		}
	}
	
	countdown = $("#countdown").countdown360({
		radius      : 30,
		seconds     : 30,					// timeout for each turn
		fontColor   : 'black',
		fillStyle	: 'rgba(150, 255, 155, 0.9)',
		strokeStyle	: 'rgba(0, 255, 0, 0.9)',
		autostart   : false,
		label			: false,
		onComplete  : function () {
								countdown.stop();
								$("#countdown").hide();
								if (!finished) {
									if (master)	{	// only the master can initiate a new turn after a timeout
										nextPlayer = next(nextPlayer);
										$.getJSON('ajax/pass.php', {		// sets the next player
											player: player,
											turn: nextPlayer
										}, function (data) {
											pass = 1;
										});
									}
								}
							}
	});
	
	$('#login').popup();
	
	// when a new player comes he will try to take a place on the latest table else starts a new table
	$.getJSON('ajax/start.php', {
		player: player,
		start: 0
	}, function(data) {
		poll();
	});

	// show the cards on the table
	function update (data) {
		
		var speler = Array('playerA','playerB','playerC','playerD','playerA','playerB','playerC','playerD');
		var key, val, i = 0, start = -1;

		// show scores when the game has finished
		finished = (parseInt(data.finished)==1);
		if (finished && started == 1)
			winner(player);		

		/*if (started==1 && JSON.stringify(bid)==JSON.stringify(data.bid)) {
			console.log('return');
			return;		
		}*/
		
		cardsleft = 0;
		$.each(data.players, function (key, val) {	// find the current player
			if (val.ID == player) 
				start = i;
			cardsleft += val.hand.lenght;
			i++;
		});
		i = start;
		
		if (oldcardsleft == cardsleft)
			return;
		oldcardsleft = cardsleft;
		
		if (data.started != '0' && !finished) {
			$('.play').toggle(speler[i]==data.turn);
			$('.pass').toggle(speler[i]==data.turn && passes<3);
		}

		// display all players clockwise on the table
		
		if (pause==false || finished) {	// don't update when it is your turn
			pause = true;
			
			$('.hand div').each(function () {	// remove selection
				$(this).removeAttr("selected");
				$(this).removeClass("focus");
			});			
						
			key = speler[i];
			val = data['players'][key];
			$('.hand').attr("player", key);
			var aantal = val.hand.length;
			var width = aantal*25+110;
			if (parseInt($('.hand').attr("count")) != aantal) {	// only update when there are changes
				$('.hand').attr("count", aantal);
				$('.hand').css({
					'width': width+'px',
					'left': ($(window).width()-width)/2+'px'
				});
				var circle = 1.6 - (1.6/(aantal-1)); // display the cards in a 30 degrees circle
				var step = circle / (aantal-1);
				var rotate = -circle/2;					// start position
				$('.hand .card').css("display", "none");
				for (var key=0; key<val.hand.length; key++) {
					card = val.hand[key];
					var cardname = sprintf(".card%s%s", card[0], card[1]);
					var rot = sprintf("rotate(%srad)", rotate);
					$(cardname).attr("angle", rotate);
					$(cardname).css({
						"left":	key*20+"px",
						"top":	"0px",
						"transform-origin": "50% 50%",
						"-webkit-transform": rot,
						"-moz-transform": rot,
						"-ms-transform": rot,
						"-o-transform": rot,
						"transform": rot,
						"display": "block",
						"z-index": key
					});
					rotate += step;
				}
				if (aantal == 1)
					pepper($('.hand'), 200, 10);
			}
		}
		
		key = speler[++i];
		val = data['players'][key];
		$('.left .name').html(val.name);
		$('.left').attr("player", key);
		var aantal = val.hand.length;
		var height = aantal*15+140;
		if (parseInt($('.left').attr("count")) != aantal) {	// only update when there are changes
			$('.left .blank_side').css("display", "none");
			$('.left').attr("count", aantal);
			$('.left').css({
				'height': height+'px',
				'top': ($(window).height()-height)/2-100+'px'
			});
			for (var key=0; key<val.hand.length; key++) {
				var cardname = sprintf(".left .card_v%s", key+1);
				$(cardname).css({
					"top":	key*20+50+"px",
					"left": "10px",
					"display": "block",
					"z-index": key
				});
			}
			if (aantal == 1)
				pepper($('.left'), 20, 100);
		}

		key = speler[++i];
		val = data['players'][key];
		$('.top .name').html(val.name);
		$('.top').attr("player", key);
		var aantal = val.hand.length;
		var width = aantal*20+115;
		if (parseInt($('.top').attr("count")) != aantal) {	// only update when there are changes
			$('.top .blank_side').css("display", "none");
			$('.top').attr("count", aantal);
			$('.top').css({
				'width': width+'px',
				'left': ($(window).width()-width)/2-width/2+'px'
			});
			for (var key=0; key<val.hand.length; key++) {
				var cardname = sprintf(".top .card_h%s", key+1);
				$(cardname).css({
					"right": key*20+40+"px",
					"top":	"30px",
					"display": "block",
					"z-index": key
				});			
			}
			if (aantal == 1)
				pepper($('.top'), 100, 30);
		}
		
		key = speler[++i];
		val = data['players'][key];
		$('.right .name').html(val.name);
		$('.right').attr("player", key);
		var aantal = val.hand.length;
		var height = aantal*15+140;
		if (parseInt($('.right').attr("count")) != aantal) {	// only update when there are changes
			$('.right .blank_side').css("display", "none");
			$('.right').attr("count", aantal);
			$('.right').css({
				'height': height+'px',
				'top': ($(window).height()-height)/2-100+'px'
			});
			for (var key=0; key<val.hand.length; key++) {
				var cardname = sprintf(".right .card_v%s", key+1);
				$(cardname).css({
					"bottom":	key*20-140+"px",
					"left": "10px",
					"display": "block",
					"z-index": key
				});
			}
			if (aantal == 1)	// last card
				pepper($('.right'), 20, 100);
		}
	
		// display the deal
		bid = data.bid;
		if (bid != 0) {
			showDeal(bid);
		}
	}	
	
	var tel_finished=0;
	var tel_running=0;
	var tel_countdown=0;
	// the main program loop
	function poll() {
		// update the status
		$.getJSON('ajax/status.php', {
			player: player,
			name: $('#name').val(),
			start: started
		}, function(data) {
			if (finished) {
				$("#countdown").hide();
				$("#pepper").hide();
				update(data);
			} else {
				if (data.started=='1' && started==0) {		// hide the start-up options for other users when started 
					started = 1;
					$("#start").hide();
					$('.play').show();
					$('.pass').show();
				}
				nextPlayer = data.turn;
				passes = data.pass;	// when each player passes (=3) the player can start a new bid
				update(data);			// show the new play field
				if (started) {		// show and start the countdown timer
					if (data.turn != turn) {
						CountDown(data);	
						turn = data.turn;
						pause = false;
						
						// calculate computer move
						$.each(data.players, function (key, val) {
							if (key==data.turn && val.name.substr(0,2)=='电脑')
								computer = true;
						});
						if (master && computer) {		// calculate a computer move
							$(".pass").click();
							console.log('computer');
							computer = false;
						}						
					}
				}				
			}			
			setTimeout(function () {poll();}, seconds);	// next poll
		});
	}

	// start the game and prevent other payers to join the table
	$(".start").on('click', function () {
		started = 1;
		master = true;		// sets the initiator of the game
		pass = 0;
		finished = false;	

		$("#start").hide();
		$('.play').show();
		$('.pass').show(); 
	});

	
	// play the selected cards
	$(".play").on('click', function () {
		deal = [];
		$('.hand div').each(function () {	// find the selected cards
			if ($(this).attr("selected")) {
				deal.push([$(this).attr("suit"), $(this).attr("rank")]);
			}	
		});

		if (passes >0 && bid==0) {		// skip the lowest card rule when no bid and previous player passes
			if (type_of(deal) > 0) {
				showDeal(deal);
				nextPlayer = next(nextPlayer);
				
				// store the deal, reset passes
				$.getJSON('ajax/engine.php', {
					player: player,
					deal: deal,
					turn: nextPlayer
				}, function(data) {
					if (data['ok'] == true) {
						countdown.stop();
						pause = false;
					}
				});
				return;
			}
		}
			
		if (checkDeal(bid, deal, passes) == true) {
			showDeal(deal);
			nextPlayer = next(nextPlayer);
			
			// store the deal, reset passes
			$.getJSON('ajax/engine.php', {
				player: player,
				deal: deal,
				turn: nextPlayer
			}, function(data) {
				if (data['ok'] == true) {
					countdown.stop();
					pause = false;
				}
			});
		}
	});
	
	// pass
	$(".pass").on('click', function () {
		nextPlayer = next(nextPlayer);
		$.getJSON('ajax/pass.php', {		// set next player
			player: player,
			turn: nextPlayer
		}, function (data) {
			countdown.stop();
			pass = 1;
		});	
	});
	
	$(document).on("click", ".card", function () {	// take a card in/out of the hand
		pause = true;
		if ($(this).attr('selected')) {	// restore original position
			var top = $(this).attr("top");
			var left = $(this).attr("left");
			
			$(this).removeAttr('selected');
			$(this).removeClass("focus");
		} else {		// stick the card out of the hand
			var top = parseInt($(this).css("top"));
			var left = parseInt($(this).css("left"));
			var angle = parseFloat($(this).attr("angle"));

			$(this).attr("top", top);
			$(this).attr("left", left);
			top -= 30*Math.cos(angle);
			left += 30*Math.sin(angle);
			$(this).attr('selected', 'selected');
			$(this).addClass("focus");
		}
		$(this).css({"top": top+"px", "left": left+"px"});
	});
	
	$("#scores #score_close").on('click', function () {
		$('#scores').popdown();
		if (finished) {	// restart the game
			$.getJSON('ajax/restart.php', {		// set next player
				player: player
			}, function (data) {
			});		
			master = false;
			pause = false;		
		}
	});
	
	$("#login #login_close").on('click', function () {
		var naam = $('#name').val();
		if (naam.length == 0)
			return;
		$('#login').popdown();
	});
});

</script>


</head>

<body>

<div id="login" style="display:none">
<center>
名字: <input type="text" id="name">
<input type="button" value="OK" id="login_close">
</center>
</div>

<div id="scores" style="display:none">
	<table width="100%">
	<thead>
		<tr><th id="plA"></th><th id="plB"></th><th id="plC">playerC</th><th id="plD"></th></tr>
	</thead>
	<tbody>
		<tr><td colspan="4">
			<div style="height:10em; overflow:auto;">
			<table id="lines" width="100%">	</table>
			</div>
		</td></tr>
	</tbody>
	<tfoot>
		<tr><td colspan="4"><hr></td></tr>
		<tr><th id="SA">0</th><th id="SB">0</th><th id="SC">0</th><th id="SD">0</th></tr>	
	</tfoot>
	</table>
	<center><input type="button" value="ok" id="score_close"></center>
</div>


<div id="countdown" style="display:none"></div>
<div id="pepper" style="display:none"></div>

<!-- the playfield -->
<div class="wrapper">
	<div class="main">
		<div class="box sidebar">
			<div class="left"><div class='name'></div></div>
		</div>
		<div class="main">
			<div class="header">
				<div class="top"><div class='name'></div></div>
			</div>
			<div class="box content"><div id="bid"></div></div>
		</div>
		<div class="box sidebar">
			<div class="right"><div class='name'></div></div>    
		</div>
	</div>
	<div class="footer">
		<div class="hand"></div>
		<table width=100%>
			<tr>
				<td>
					<br><input type="button" value="开始" hint="start" class="start" id="start">
				</td>
				<td>
					<br><input type="button" value="打法" hint="play" class="play" style="display:none">&nbsp;&nbsp;
					<input type="button" value="放行" hint="pass" class="pass" style="display:none">
			</td>
			</tr>
		</table>	
	</div>
</div>


</body>
</html>