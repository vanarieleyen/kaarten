
function showDeal(bid) {
	$('#bid').empty();
	var aantal = bid.length;
	var width = aantal*20+115;
	
	for (var i=0; i<bid.length; i++) {
		var card = bid[i];
		var cardname = sprintf("card%s%s", card[0], card[1]);
		$('#bid').append(sprintf("<div class='card %s' style='left:%spx; top:0px; display:block'></div>", 
								cardname, i*20+width));
	}
}

// checks if the deal is valid
function checkDeal(bid, deal, passes) {
	var ok;

	deal.sort(function (a, b) {	// deals must be sorted before they can be checked
		if (parseInt(a[1]) > parseInt(b[1])) {
			return true;
		} else if(a[1] == b[1]) {
			return parseInt(a[0]) - parseInt(b[0]);
		} else {
			return false;
		}				
	});

	if (bid == 0) {		// the first round (deal must include the diamonds-2)
		var R2 = false;
		for (var i=0; i<deal.length; i++) {
			var card = deal[i];
			if (parseInt(card[0])==1 && parseInt(card[1])==1)
				R2 = true;
		}
		ok = (R2) ? (type_of(deal) > 0) : false;	// if diamond-2 is found then check if it is a valid deal
	} else {	// not the first round - check if it is a valid deal
		ok = (passes >= 3) ? (type_of(deal) > 0) : valid(bid, deal); // when everybody passes the player can start a new deal
	}
	return ok;
}

// check to see if the deal is according to the bid and has a higher value
function valid(bid, deal) {
	if (bid.length != deal.length)		// check the amount of cards
		return false;

	if (type_of(bid) < type_of(deal))		// check the type of street
		return true;

	return evaluate(bid) < evaluate(deal);	// checks which is larger
}


// returns the value of the deal
function evaluate(cards) {
	var len = cards.length;
	if (len < 5)
		return parseInt(cards[len-1][0]) + 4*parseInt(cards[len-1][1]);	// only use the highest card

	var street = type_of(cards);		// 1..8
	var pnt = 0;
	if (street==6 || street==7) {
		var firstCard = parseInt(cards[0][1]);
		var a = 0;
		var b = 0;
		var sumA = 0;
		var sumB = 0;
		for (var i=0; i<cards.length; i++) {
			var val = cards[i];
			if (parseInt(val[1]) != firstCard) {
				a++;
				sumA += parseInt(val[1]);
			} else {
				b++;
				sumB += parseInt(val[1]);
			}
		}
		pnt = (a > b) ? sumA : sumB;
	} else {
		return parseInt(cards[len-1][0]) + 4*parseInt(cards[len-1][1]);	// only use the highest card
	}
	// pnt can not be higher than 6565, so street must be multiplied by 6565 or higher
	return 10000*street + pnt;
}

// checks the deal, returns type of deal or 0 on error
function type_of(deal) {
	var bits, straight, flush, fullhouse, fourkind;

	switch (deal.length) {
		case 1: 	return 1;
		case 2: 	bits = parseInt(deal[0][1]) & parseInt(deal[1][1]);
					return (bits == parseInt(deal[0][1])) ? 2 : 0;
		case 3:	bits = parseInt(deal[0][1]) & parseInt(deal[1][1]) & parseInt(deal[2][1]);
					return (bits == parseInt(deal[0][1])) ? 3 : 0;
		case 5:	straight = isStraight(deal);
					flush = isFlush(deal);
					fullhouse = isFullhouse(deal);
					fourkind = is4kind(deal);
					if (straight && flush) {
						return 8;
					} else if(fourkind) {
						return 7;
					} else if(fullhouse) {
						return 6;
					} else if (flush) {
						return 5;
					} else if (straight) {
						return 4;
					} else
						return 0;
					break;
		default:	return 0;
	}
}	

// is 5 in a row (various suits)
function isStraight(deal) {
	var next = parseInt(deal[0][1]);
	for (var i=0; i<deal.length; i++) {
		var card = deal[i];
		if (parseInt(card[1]) != next)
			return (parseInt(card[1])==13);
		next++; 
	}
	return true;
}

// is 5 with the same suits
function isFlush(deal) {
	var suit = parseInt(deal[0][0]);
	for (var i=0; i<deal.length; i++) {
		var card = deal[i];
		if (parseInt(card[0]) != suit)
			return false;
	};
	return true;
}

// is 3 + 2 the same suits
function isFullhouse(deal) {
	if ((parseInt(deal[0][1])-parseInt(deal[1][1]) | parseInt(deal[3][1])-parseInt(deal[4][1])) == 0) {
		return (parseInt(deal[2][1])==parseInt(deal[0][1]) || parseInt(deal[2][1])==parseInt(deal[4][1]));
	}
	return false;
}

// is 4 of a kind (1 + 4 same suits)
function is4kind(deal) {
	// middle 3 cards must be the same
	return (parseInt(deal[1][1])==parseInt(deal[2][1]) && parseInt(deal[1][1])==parseInt(deal[3][1]));	
}

////////////////////////////////////////////////////////////////////////////////////////////////

// returns the next player (playerA, playerB....)
function next(currentPlayerID) {
	var letter = String.charCodeAt(currentPlayerID.slice(-1))+1;
	var NP = (letter == String.charCodeAt('E')) ? 'playerA' : 'player'+String.fromCharCode(letter); 
	
	//console.log(currentPlayerID+' '+NP);
	return NP;
}		
		
// show the countdown timer
function CountDown(data) {
	var element = $('.wrapper').children().find('[player='+data.turn+']');
	if (element.length == 0) {
		return;	
	}
	
	var position = $(element).offset();

	// place the countdown timer
	$("#countdown").css({
		'top': position.top+element.height()/2+'px',			
		'left': position.left+element.width()/2+'px'
	});
	$("#countdown").show();

	timer.start();
}

// show the last card warning
function pepper(element, x, y) {
	var position = $(element).offset();
	$("#pepper").css({
		'top':  position.top+y+'px',			
		'left': position.left+x+'px'
	});
	$("#pepper").show();
}

// set winner of the game and display results
function winner(player) {

	timer.stop();
	started = 0;
	pass = 0;
	finished = true;

	$('#bid').empty();
	$("#start").show();
	$('.play').hide();
	$('.pass').hide(); 
	$("#pepper").hide();

	$.getJSON('ajax/scores.php', {
		player: player
	}, function (data) {
		
		$('#scores #plA').html(data[0][0]);	// names
		$('#scores #plB').html(data[1][0]);
		$('#scores #plC').html(data[2][0]);
		$('#scores #plD').html(data[3][0]);

		var html = sprintf("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>",  
									data[0][1], data[1][1], data[2][1], data[3][1]);
		$("#scores #lines").append(html);	// scores
		
		var SA = parseInt($('#scores #SA').text())+data[0][1];
		var SB = parseInt($('#scores #SB').text())+data[1][1];
		var SC = parseInt($('#scores #SC').text())+data[2][1];
		var SD = parseInt($('#scores #SD').text())+data[3][1];
		$('#scores #SA').text(SA);
		$('#scores #SB').text(SB);
		$('#scores #SC').text(SC);
		$('#scores #SD').text(SD);
		
		$('#scores').popup();
	});	
}

// generates a unique id for the player
function uniqueID(){
	function chr4(){
		return Math.random().toString(16).slice(-4);
	}
	return chr4() + chr4() +
				'-' + chr4() +
				'-' + chr4() +
				'-' + chr4() +
				'-' + chr4() + chr4() + chr4();
}

// return image-name of card
function getCard(color, nr){
	var kar, kleur;
	switch(nr) {
		case 1:	kar = 'A';	break;
		case 11:	kar = 'J';	break;
		case 12:	kar = 'Q';	break;
		case 13:	kar = 'K';	break;
		default: kar = nr;
	}
	switch(color) {
		case 1:	kleur = 'R';	break;	
		case 2:	kleur = 'K';	break;
		case 3:	kleur = 'H';	break;
		case 4:	kleur = 'S';	break;
	}	
	return 'images/'+kleur+kar+'.png';
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////

/* sprintf function */
//https://github.com/alexei/sprintf.js/blob/master/src/sprintf.js
(function(window) {
    'use strict'

    var re = {
        not_string: /[^s]/,
        not_bool: /[^t]/,
        not_type: /[^T]/,
        not_primitive: /[^v]/,
        number: /[diefg]/,
        numeric_arg: /bcdiefguxX/,
        json: /[j]/,
        not_json: /[^j]/,
        text: /^[^\x25]+/,
        modulo: /^\x25{2}/,
        placeholder: /^\x25(?:([1-9]\d*)\$|\(([^\)]+)\))?(\+)?(0|'[^$])?(-)?(\d+)?(?:\.(\d+))?([b-gijostTuvxX])/,
        key: /^([a-z_][a-z_\d]*)/i,
        key_access: /^\.([a-z_][a-z_\d]*)/i,
        index_access: /^\[(\d+)\]/,
        sign: /^[\+\-]/
    }

    function sprintf() {
        var key = arguments[0], cache = sprintf.cache
        if (!(cache[key] && cache.hasOwnProperty(key))) {
            cache[key] = sprintf.parse(key)
        }
        return sprintf.format.call(null, cache[key], arguments)
    }

    sprintf.format = function(parse_tree, argv) {
        var cursor = 1, tree_length = parse_tree.length, node_type = '', arg, output = [], i, k, match, pad, pad_character, pad_length, is_positive = true, sign = ''
        for (i = 0; i < tree_length; i++) {
            node_type = get_type(parse_tree[i])
            if (node_type === 'string') {
                output[output.length] = parse_tree[i]
            }
            else if (node_type === 'array') {
                match = parse_tree[i] // convenience purposes only
                if (match[2]) { // keyword argument
                    arg = argv[cursor]
                    for (k = 0; k < match[2].length; k++) {
                        if (!arg.hasOwnProperty(match[2][k])) {
                            throw new Error(sprintf('[sprintf] property "%s" does not exist', match[2][k]))
                        }
                        arg = arg[match[2][k]]
                    }
                }
                else if (match[1]) { // positional argument (explicit)
                    arg = argv[match[1]]
                }
                else { // positional argument (implicit)
                    arg = argv[cursor++]
                }

                if (re.not_type.test(match[8]) && re.not_primitive.test(match[8]) && get_type(arg) == 'function') {
                    arg = arg()
                }

                if (re.numeric_arg.test(match[8]) && (get_type(arg) != 'number' && isNaN(arg))) {
                    throw new TypeError(sprintf("[sprintf] expecting number but found %s", get_type(arg)))
                }

                if (re.number.test(match[8])) {
                    is_positive = arg >= 0
                }

                switch (match[8]) {
                    case 'b':
                        arg = parseInt(arg, 10).toString(2)
                    break
                    case 'c':
                        arg = String.fromCharCode(parseInt(arg, 10))
                    break
                    case 'd':
                    case 'i':
                        arg = parseInt(arg, 10)
                    break
                    case 'j':
                        arg = JSON.stringify(arg, null, match[6] ? parseInt(match[6]) : 0)
                    break
                    case 'e':
                        arg = match[7] ? parseFloat(arg).toExponential(match[7]) : parseFloat(arg).toExponential()
                    break
                    case 'f':
                        arg = match[7] ? parseFloat(arg).toFixed(match[7]) : parseFloat(arg)
                    break
                    case 'g':
                        arg = match[7] ? parseFloat(arg).toPrecision(match[7]) : parseFloat(arg)
                    break
                    case 'o':
                        arg = arg.toString(8)
                    break
                    case 's':
                        arg = String(arg)
                        arg = (match[7] ? arg.substring(0, match[7]) : arg)
                    break
                    case 't':
                        arg = String(!!arg)
                        arg = (match[7] ? arg.substring(0, match[7]) : arg)
                    break
                    case 'T':
                        arg = get_type(arg)
                        arg = (match[7] ? arg.substring(0, match[7]) : arg)
                    break
                    case 'u':
                        arg = parseInt(arg, 10) >>> 0
                    break
                    case 'v':
                        arg = arg.valueOf()
                        arg = (match[7] ? arg.substring(0, match[7]) : arg)
                    break
                    case 'x':
                        arg = parseInt(arg, 10).toString(16)
                    break
                    case 'X':
                        arg = parseInt(arg, 10).toString(16).toUpperCase()
                    break
                }
                if (re.json.test(match[8])) {
                    output[output.length] = arg
                }
                else {
                    if (re.number.test(match[8]) && (!is_positive || match[3])) {
                        sign = is_positive ? '+' : '-'
                        arg = arg.toString().replace(re.sign, '')
                    }
                    else {
                        sign = ''
                    }
                    pad_character = match[4] ? match[4] === '0' ? '0' : match[4].charAt(1) : ' '
                    pad_length = match[6] - (sign + arg).length
                    pad = match[6] ? (pad_length > 0 ? str_repeat(pad_character, pad_length) : '') : ''
                    output[output.length] = match[5] ? sign + arg + pad : (pad_character === '0' ? sign + pad + arg : pad + sign + arg)
                }
            }
        }
        return output.join('')
    }

    sprintf.cache = {}

    sprintf.parse = function(fmt) {
        var _fmt = fmt, match = [], parse_tree = [], arg_names = 0
        while (_fmt) {
            if ((match = re.text.exec(_fmt)) !== null) {
                parse_tree[parse_tree.length] = match[0]
            }
            else if ((match = re.modulo.exec(_fmt)) !== null) {
                parse_tree[parse_tree.length] = '%'
            }
            else if ((match = re.placeholder.exec(_fmt)) !== null) {
                if (match[2]) {
                    arg_names |= 1
                    var field_list = [], replacement_field = match[2], field_match = []
                    if ((field_match = re.key.exec(replacement_field)) !== null) {
                        field_list[field_list.length] = field_match[1]
                        while ((replacement_field = replacement_field.substring(field_match[0].length)) !== '') {
                            if ((field_match = re.key_access.exec(replacement_field)) !== null) {
                                field_list[field_list.length] = field_match[1]
                            }
                            else if ((field_match = re.index_access.exec(replacement_field)) !== null) {
                                field_list[field_list.length] = field_match[1]
                            }
                            else {
                                throw new SyntaxError("[sprintf] failed to parse named argument key")
                            }
                        }
                    }
                    else {
                        throw new SyntaxError("[sprintf] failed to parse named argument key")
                    }
                    match[2] = field_list
                }
                else {
                    arg_names |= 2
                }
                if (arg_names === 3) {
                    throw new Error("[sprintf] mixing positional and named placeholders is not (yet) supported")
                }
                parse_tree[parse_tree.length] = match
            }
            else {
                throw new SyntaxError("[sprintf] unexpected placeholder")
            }
            _fmt = _fmt.substring(match[0].length)
        }
        return parse_tree
    }

    var vsprintf = function(fmt, argv, _argv) {
        _argv = (argv || []).slice(0)
        _argv.splice(0, 0, fmt)
        return sprintf.apply(null, _argv)
    }

    /**
     * helpers
     */
    function get_type(variable) {
        if (typeof variable === 'number') {
            return 'number'
        }
        else if (typeof variable === 'string') {
            return 'string'
        }
        else {
            return Object.prototype.toString.call(variable).slice(8, -1).toLowerCase()
        }
    }

    var preformattedPadding = {
        '0': ['', '0', '00', '000', '0000', '00000', '000000', '0000000'],
        ' ': ['', ' ', '  ', '   ', '    ', '     ', '      ', '       '],
        '_': ['', '_', '__', '___', '____', '_____', '______', '_______'],
    }
    function str_repeat(input, multiplier) {
        if (multiplier >= 0 && multiplier <= 7 && preformattedPadding[input]) {
            return preformattedPadding[input][multiplier]
        }
        return Array(multiplier + 1).join(input)
    }

    /**
     * export to either browser or node.js
     */
    if (typeof exports !== 'undefined') {
        exports.sprintf = sprintf
        exports.vsprintf = vsprintf
    }
    else {
        window.sprintf = sprintf
        window.vsprintf = vsprintf

        if (typeof define === 'function' && define.amd) {
            define(function() {
                return {
                    sprintf: sprintf,
                    vsprintf: vsprintf
                }
            })
        }
    }
})(typeof window === 'undefined' ? this : window);
